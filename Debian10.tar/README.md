# CYBERTIZE SETUP MANAGER [VPS]

### Cara guna:
**Langkah pertama**: Log masuk ke VPS anda

**Langkah kedua**: Masukkan perintah: wget "https://raw.githubusercontent.com/cybertize-dev/Debian10/main/install"

**Langkah ketiga**: Masukkan perintah: bash install

#### Untuk paparkan menu masukkan perintah: menu

### Senarai pakej dan ports:

  openssh [-p 22]

  dropbear [-p 8695] [-p 5968]

  openvpn [-p 6545] [-p 5456]

  squid [-p 4613] [-p 3164]

  badvpn [-p 7300]

  shadowsocks [-p 6242]

  webmin [-p 10000]
